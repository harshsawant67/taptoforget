import React, { useRef } from 'react';
import { Download, X } from 'lucide-react';
import { useMemory } from '../context/MemoryContext';

const Certificate: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { memory } = useMemory();
  const certificateRef = useRef<HTMLDivElement>(null);
  
  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  
  const redactedMemory = memory.replace(/[a-zA-Z0-9]/g, '█');
  
  const generateCertificateNumber = () => {
    return 'MEM-' + Math.floor(Math.random() * 100000).toString().padStart(6, '0');
  };
  
  const downloadCertificate = () => {
    // Create a simple text-based certificate instead of PDF
    const certificateText = `
CERTIFICATE OF FORGETFULNESS
============================

This certifies that the following memory:
"${redactedMemory}"

has been permanently deleted from existence
on this day ${currentDate}

Certificate #: ${generateCertificateNumber()}
MentalFlush™ Memory Deletion Services

* This certificate is totally real and legally binding. Probably.
    `;
    
    const blob = new Blob([certificateText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'certificate-of-forgetfulness.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 bg-black/80 p-4">
      <div className="bg-gray-800 rounded-2xl p-5 md:p-8 max-w-3xl w-full max-h-[90vh] overflow-auto">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl md:text-2xl font-bold">Certificate of Forgetfulness</h2>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-white"
            aria-label="Close"
          >
            <X size={24} />
          </button>
        </div>
        
        <div 
          ref={certificateRef}
          className="bg-gray-900 border-4 border-purple-500 rounded-xl p-6 md:p-8 mb-6"
        >
          <div className="flex justify-center mb-4">
            <div className="bg-purple-600 px-4 py-1 rounded-full text-sm font-medium">
              OFFICIAL DOCUMENT
            </div>
          </div>
          
          <h2 className="text-center text-2xl md:text-3xl font-bold mb-6 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 text-transparent bg-clip-text">
            CERTIFICATE OF FORGETFULNESS
          </h2>
          
          <p className="text-center text-gray-300 mb-2">
            You successfully forgot:
          </p>
          
          <p className="text-center text-gray-300 mb-4">
            This certifies that the following memory:
          </p>
          
          <div className="bg-black/50 rounded-lg p-4 mb-6 border border-gray-700 font-mono">
            <p className="text-gray-400 break-words">
              {redactedMemory}
            </p>
          </div>
          
          <p className="text-center text-gray-300 mb-1">
            has been permanently deleted from existence
          </p>
          <p className="text-center text-gray-300 mb-6">
            on this day {currentDate}
          </p>
          
          <div className="flex justify-center mb-6">
            <div className="h-px w-40 bg-gradient-to-r from-transparent via-purple-500 to-transparent"></div>
          </div>
          
          <div className="text-center text-gray-400 text-sm">
            <p>Certificate #: {generateCertificateNumber()}</p>
            <p>MentalFlush™ Memory Deletion Services</p>
          </div>
        </div>
        
        <div className="flex justify-center">
          <button
            onClick={downloadCertificate}
            className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-4 rounded-lg transition-colors"
          >
            <Download size={18} />
            Download Certificate
          </button>
        </div>
      </div>
    </div>
  );
};

export default Certificate;