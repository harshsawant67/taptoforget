import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="py-6 bg-gray-900/80 backdrop-blur-sm border-t border-purple-900/30">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-center md:text-left">
            <p className="text-gray-400 text-sm">
              <span className="text-purple-400">MentalFlush™</span> - Making forgetting great again since 2025
            </p>
            <p className="text-gray-500 text-xs mt-1">
              Disclaimer: No actual memories are deleted. This is a joke website.
            </p>
          </div>
          
          <a 
            href="https://bolt.new"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:opacity-90 transition-opacity"
          >
            <img 
              src="/image.png" 
              alt="Made with Bolt"
              className="h-8"
            />
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;