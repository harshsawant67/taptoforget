import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, Brain } from 'lucide-react';

const Header: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <header 
      className={`sticky top-0 z-10 transition-all duration-300 ${
        scrolled 
          ? 'bg-gray-900/90 backdrop-blur-md shadow-lg py-2' 
          : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link to="/" className="flex items-center gap-2 hover:opacity-90 transition-opacity">
          <Brain className="h-8 w-8 text-purple-400" />
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
            <span className="text-white">Mental</span>
            <span className="bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 text-transparent bg-clip-text">
              Flush
            </span>
          </h1>
        </Link>
        
        <div className="flex items-center gap-3">
          <div className="hidden md:flex items-center gap-2 bg-gray-800/80 px-3 py-1 rounded-full text-sm">
            <Sparkles className="h-4 w-4 text-yellow-400" />
            <span className="text-gray-300">Memory Deletion Service</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;