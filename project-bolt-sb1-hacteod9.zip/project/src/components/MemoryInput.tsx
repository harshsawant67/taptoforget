import React, { useState, useRef } from 'react';
import { Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';
import { Player } from '@lottiefiles/react-lottie-player';
import { useMemory } from '../context/MemoryContext';
import Certificate from './Certificate';
import { getSarcasticResponse } from '../utils/responses';

const MemoryInput: React.FC = () => {
  const { 
    memory, 
    setMemory, 
    isDeleting, 
    setIsDeleting, 
    incrementDeletedMemories,
    showCertificate,
    setShowCertificate
  } = useMemory();
  
  const [isProcessing, setIsProcessing] = useState(false);
  
  const playerRef = useRef<Player>(null);

  const handleForget = async () => {
    if (!memory.trim()) {
      toast.error('Please enter a memory first! 🧠');
      return;
    }

    // Show confirmation dialog
    if (!window.confirm(`🚨 WARNING 🚨\n\nAre you absolutely, positively sure you want to permanently erase "${memory}" from existence?\n\nThis process cannot be undone and may cause existential dread.`)) {
      toast('Phew! Your memory lives to haunt you another day.', {
        icon: '😅',
      });
      return;
    }

    // Show sarcastic response
    setIsProcessing(true);
    const sarcasticResponse = getSarcasticResponse(memory);
    await new Promise(resolve => setTimeout(resolve, 500));
    toast(sarcasticResponse, {
      icon: '🤔',
      duration: 3000,
    });

    // Wait a bit before starting the animation
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsProcessing(false);
    
    // Start memory deletion animation
    setIsDeleting(true);
    playerRef.current?.play();
    
    // Sound effect
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2006/2006-preview.mp3');
    audio.volume = 0.4;
    audio.play().catch(e => console.log('Audio play failed:', e));

    // Wait for animation to finish
    setTimeout(() => {
      toast.success('Memory successfully deleted!', {
        icon: '💀',
        duration: 3000,
      });
      
      incrementDeletedMemories();
      
      // Show completed message
      setTimeout(() => {
        setIsDeleting(false);
        setShowCertificate(true);
      }, 1000);
    }, 3000);
  };

  const handleCloseModal = () => {
    setShowCertificate(false);
    setMemory('');
  };

  return (
    <div className="w-full max-w-2xl mx-auto mb-8">
      {!isDeleting && !showCertificate ? (
        <div className="relative">
          <div className="bg-gray-800/70 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/30 shadow-lg shadow-purple-500/10">
            <h2 className="text-2xl md:text-3xl font-bold mb-6 text-center">
              <span className="text-pink-400">🧠</span> What would you like to forget?
            </h2>
            
            <div className="mb-6">
              <div className="relative">
                <textarea 
                  value={memory}
                  onChange={(e) => setMemory(e.target.value)}
                  placeholder="That embarrassing thing I did in 2017..."
                  className="w-full h-32 rounded-xl bg-gray-900/80 border border-purple-500/40 p-4 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
              
              <p className="text-sm text-gray-400 mt-2 italic">
                * We promise to "delete" this memory forever. Wink wink. 😉
              </p>
            </div>
            
            <button
              onClick={handleForget}
              disabled={!memory.trim() || isProcessing}
              className={`w-full py-4 rounded-xl font-bold text-lg shadow-lg transition-all duration-300 flex items-center justify-center gap-2 ${
                !memory.trim() || isProcessing
                  ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white hover:shadow-pink-500/20 hover:shadow-xl'
              }`}
            >
              {isProcessing ? (
                <>
                  <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div>
                  Processing...
                </>
              ) : (
                <>
                  <Trash2 size={20} />
                  Forget Forever
                </>
              )}
            </button>
          </div>
          
          <div className="text-center mt-4 text-sm text-purple-300/80">
            <p>⚠️ No actual memories are harmed in this process ⚠️</p>
          </div>
        </div>
      ) : isDeleting ? (
        <div className="flex flex-col items-center justify-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center animate-pulse">
            <span className="text-pink-400">Deleting Memory</span> 💭
          </h2>
          
          <div className="w-full max-w-md mx-auto">
            <Player
              ref={playerRef}
              autoplay
              loop
              src="https://assets5.lottiefiles.com/packages/lf20_jmBhHa.json"
              style={{ height: '300px', width: '300px' }}
            />
          </div>
          
          <p className="text-xl font-medium text-center mt-4 animate-pulse">
            Please wait while we erase this from existence...
          </p>
        </div>
      ) : null}
      
      {showCertificate && <Certificate onClose={handleCloseModal} />}
    </div>
  );
};

export default MemoryInput;