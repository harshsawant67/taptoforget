import React, { createContext, useState, useContext, ReactNode } from 'react';

interface MemoryContextType {
  memory: string;
  setMemory: (memory: string) => void;
  isDeleting: boolean;
  setIsDeleting: (isDeleting: boolean) => void;
  deletedMemories: number;
  incrementDeletedMemories: () => void;
  showCertificate: boolean;
  setShowCertificate: (show: boolean) => void;
  generateRandomDeletedCount: () => number;
}

const MemoryContext = createContext<MemoryContextType | undefined>(undefined);

export const MemoryProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [memory, setMemory] = useState<string>('');
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [deletedMemories, setDeletedMemories] = useState<number>(
    Math.floor(Math.random() * 10000) + 5000
  );
  const [showCertificate, setShowCertificate] = useState<boolean>(false);

  const incrementDeletedMemories = () => {
    setDeletedMemories(prevCount => prevCount + 1);
  };

  const generateRandomDeletedCount = () => {
    return Math.floor(Math.random() * 500) + 100;
  };

  return (
    <MemoryContext.Provider
      value={{
        memory,
        setMemory,
        isDeleting,
        setIsDeleting,
        deletedMemories,
        incrementDeletedMemories,
        showCertificate,
        setShowCertificate,
        generateRandomDeletedCount,
      }}
    >
      {children}
    </MemoryContext.Provider>
  );
};

export const useMemory = (): MemoryContextType => {
  const context = useContext(MemoryContext);
  if (context === undefined) {
    throw new Error('useMemory must be used within a MemoryProvider');
  }
  return context;
};