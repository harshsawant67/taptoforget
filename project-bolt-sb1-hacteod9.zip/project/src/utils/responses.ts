export const getSarcasticResponse = (memory: string): string => {
  const responses = [
    "Oh, THAT'S what you want to forget? Interesting choice... 🤔",
    "Are you sure that's your worst memory? I've seen people delete way worse!",
    "Analyzing memory... Yep, that's definitely embarrassing enough to delete.",
    "Your brain will thank you for deleting THAT one!",
    "I'll pretend I didn't see that before I delete it. Yikes!",
    "That memory is so bad even our AI wants to forget it!",
    "Wow. Just... wow. No judgment, but... actually, a little judgment.",
    "If I had a nickel for every time someone wanted to forget that exact thing...",
    "Our algorithm rates this memory a solid 8/10 on the cringe scale.",
    "Memory received. I'd want to forget that too if I were you.",
    "Sure, I'll delete that. Between us, though? Therapy might help too.",
    "That's... unique. The void welcomes your contribution!",
    "My circuits are blushing. Let's delete this ASAP.",
    "Initiating selective amnesia protocol. Good choice, by the way.",
    "Loading judgment.exe... Just kidding! Preparing deletion."
  ];
  
  // Return a random response
  return responses[Math.floor(Math.random() * responses.length)];
};