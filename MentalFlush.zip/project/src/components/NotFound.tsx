import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Brain, AlertTriangle } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="w-full max-w-2xl mx-auto text-center">
      <div className="bg-gray-800/70 backdrop-blur-sm rounded-2xl p-8 border border-purple-500/30 shadow-lg shadow-purple-500/10">
        <div className="flex justify-center mb-6">
          <div className="relative">
            <Brain className="h-24 w-24 text-purple-400" />
            <AlertTriangle className="h-8 w-8 text-red-400 absolute -top-2 -right-2" />
          </div>
        </div>
        
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          <span className="bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 text-transparent bg-clip-text">
            404
          </span>
        </h1>
        
        <h2 className="text-2xl md:text-3xl font-bold mb-6 text-white">
          Memory Not Found
        </h2>
        
        <p className="text-lg text-gray-300 mb-4">
          Looks like this page has been successfully deleted from existence!
        </p>
        
        <p className="text-gray-400 mb-8 italic">
          Either that, or you've stumbled into the void where forgotten memories go to die. 💀
        </p>
        
        <div className="space-y-4">
          <Link
            to="/"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-medium py-3 px-6 rounded-xl transition-all duration-300 shadow-lg hover:shadow-pink-500/20"
          >
            <Home size={20} />
            Return to Memory Deletion
          </Link>
          
          <div className="text-sm text-gray-500 mt-4">
            <p>🧠 Fun fact: You'll probably forget you were even here!</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotFound;