import React, { useState, useEffect } from 'react';
import { useMemory } from '../context/MemoryContext';
import { Sparkles } from 'lucide-react';

const MemoryCounter: React.FC = () => {
  const { deletedMemories, generateRandomDeletedCount } = useMemory();
  const [todayCount, setTodayCount] = useState(generateRandomDeletedCount());
  
  // Randomly update the counter occasionally
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.7) {
        setTodayCount(prev => prev + Math.floor(Math.random() * 5) + 1);
      }
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full max-w-md mx-auto mt-8">
      <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-4 border border-purple-500/20 shadow-lg flex flex-col items-center">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="h-5 w-5 text-yellow-400" />
          <h3 className="text-lg font-medium text-gray-300">Memory Deletion Stats</h3>
        </div>
        
        <div className="grid grid-cols-2 w-full gap-4 mt-2">
          <div className="bg-gray-900/70 rounded-lg p-3 text-center">
            <p className="text-sm text-gray-400">Total Forgotten</p>
            <p className="text-2xl font-bold text-white">
              {deletedMemories.toLocaleString()}
            </p>
          </div>
          
          <div className="bg-gray-900/70 rounded-lg p-3 text-center">
            <p className="text-sm text-gray-400">Forgotten Today</p>
            <p className="text-2xl font-bold text-white">
              {todayCount.toLocaleString()}
            </p>
          </div>
        </div>
        
        <p className="text-xs text-gray-500 mt-3 italic text-center">
          * These numbers are totally real and not at all made up. Trust us.
        </p>
      </div>
    </div>
  );
};

export default MemoryCounter;