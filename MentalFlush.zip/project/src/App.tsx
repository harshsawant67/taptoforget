import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Header from './components/Header';
import MemoryInput from './components/MemoryInput';
import MemoryCounter from './components/MemoryCounter';
import Footer from './components/Footer';
import NotFound from './components/NotFound';
import { MemoryProvider } from './context/MemoryContext';

function App() {
  return (
    <MemoryProvider>
      <Router>
        <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white flex flex-col">
          <Toaster 
            position="top-center"
            toastOptions={{
              className: 'bg-gray-800 text-white border border-purple-500',
              duration: 4000,
            }}
          />
          <Header />
          <main className="flex-grow container mx-auto px-4 py-8 flex flex-col items-center justify-center">
            <Routes>
              <Route path="/" element={
                <>
                  <MemoryInput />
                  <MemoryCounter />
                </>
              } />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </MemoryProvider>
  );
}

export default App;