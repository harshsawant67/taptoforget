import React, { useState, useRef } from 'react';
import { Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';
import { useMemory } from '../context/MemoryContext';
import Certificate from './Certificate';
import { getSarcasticResponse } from '../utils/responses';

const MemoryInput: React.FC = () => {
  const { 
    memory, 
    setMemory, 
    isDeleting, 
    setIsDeleting, 
    incrementDeletedMemories,
    showCertificate,
    setShowCertificate
  } = useMemory();
  
  const [isProcessing, setIsProcessing] = useState(false);

  const handleForget = async () => {
    if (!memory.trim()) {
      toast.error('Please enter a memory first! 🧠');
      return;
    }

    // Show confirmation dialog
    if (!window.confirm(`🚨 WARNING 🚨\n\nAre you absolutely, positively sure you want to permanently erase "${memory}" from existence?\n\nThis process cannot be undone and may cause existential dread.`)) {
      toast('Phew! Your memory lives to haunt you another day.', {
        icon: '😅',
      });
      return;
    }

    // Show sarcastic response
    setIsProcessing(true);
    const sarcasticResponse = getSarcasticResponse(memory);
    await new Promise(resolve => setTimeout(resolve, 500));
    toast(sarcasticResponse, {
      icon: '🤔',
      duration: 3000,
    });

    // Wait a bit before starting the animation
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsProcessing(false);
    
    // Start memory deletion animation
    setIsDeleting(true);
    
    // Sound effect
    try {
      const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2006/2006-preview.mp3');
      audio.volume = 0.4;
      audio.play().catch(e => console.log('Audio play failed:', e));
    } catch (e) {
      console.log('Audio creation failed:', e);
    }

    // Wait for animation to finish
    setTimeout(() => {
      toast.success('Memory successfully deleted!', {
        icon: '💀',
        duration: 3000,
      });
      
      incrementDeletedMemories();
      
      // Show completed message
      setTimeout(() => {
        setIsDeleting(false);
        setShowCertificate(true);
      }, 1000);
    }, 4000);
  };

  const handleCloseModal = () => {
    setShowCertificate(false);
    setMemory('');
  };

  return (
    <div className="w-full max-w-2xl mx-auto mb-8">
      {!isDeleting && !showCertificate ? (
        <div className="relative">
          <div className="bg-gray-800/70 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/30 shadow-lg shadow-purple-500/10">
            <h2 className="text-2xl md:text-3xl font-bold mb-6 text-center">
              <span className="text-pink-400">🧠</span> What would you like to forget?
            </h2>
            
            <div className="mb-6">
              <div className="relative">
                <textarea 
                  value={memory}
                  onChange={(e) => setMemory(e.target.value)}
                  placeholder="That embarrassing thing I did in 2017..."
                  className="w-full h-32 rounded-xl bg-gray-900/80 border border-purple-500/40 p-4 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none"
                />
              </div>
              
              <p className="text-sm text-gray-400 mt-2 italic">
                * We promise to "delete" this memory forever. Wink wink. 😉
              </p>
            </div>
            
            <button
              onClick={handleForget}
              disabled={!memory.trim() || isProcessing}
              className={`w-full py-4 rounded-xl font-bold text-lg shadow-lg transition-all duration-300 flex items-center justify-center gap-2 ${
                !memory.trim() || isProcessing
                  ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white hover:shadow-pink-500/20 hover:shadow-xl transform hover:scale-[1.02]'
              }`}
            >
              {isProcessing ? (
                <>
                  <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div>
                  Processing...
                </>
              ) : (
                <>
                  <Trash2 size={20} />
                  Forget Forever
                </>
              )}
            </button>
          </div>
          
          <div className="text-center mt-4 text-sm text-purple-300/80">
            <p>⚠️ No actual memories are harmed in this process ⚠️</p>
          </div>
        </div>
      ) : isDeleting ? (
        <div className="flex flex-col items-center justify-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center animate-pulse">
            <span className="bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 text-transparent bg-clip-text">
              Deleting Memory
            </span> 💭
          </h2>
          
          {/* Custom CSS Animation */}
          <div className="relative w-80 h-80 flex items-center justify-center mb-6">
            {/* Brain Icon with Deletion Effect */}
            <div className="relative">
              <div className="text-8xl animate-pulse">🧠</div>
              
              {/* Deletion Lines */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-24 h-1 bg-red-500 animate-ping absolute rotate-45"></div>
                <div className="w-24 h-1 bg-red-500 animate-ping absolute -rotate-45"></div>
              </div>
              
              {/* Particles Effect */}
              <div className="absolute inset-0">
                {[...Array(8)].map((_, i) => (
                  <div
                    key={i}
                    className="absolute w-2 h-2 bg-purple-400 rounded-full animate-bounce"
                    style={{
                      left: `${20 + (i * 10)}%`,
                      top: `${20 + (i % 3) * 20}%`,
                      animationDelay: `${i * 0.2}s`,
                      animationDuration: '1s'
                    }}
                  />
                ))}
              </div>
            </div>
            
            {/* Circular Progress */}
            <div className="absolute inset-0 border-4 border-purple-500/30 rounded-full">
              <div className="w-full h-full border-4 border-transparent border-t-purple-500 rounded-full animate-spin"></div>
            </div>
          </div>
          
          {/* Memory Text Being Erased */}
          <div className="bg-gray-900/80 rounded-lg p-4 mb-6 border border-gray-700 max-w-md">
            <div className="font-mono text-gray-400 relative overflow-hidden">
              <div className="animate-pulse">
                {memory.split('').map((char, i) => (
                  <span
                    key={i}
                    className="inline-block"
                    style={{
                      animation: `fadeOut 0.1s ease-in-out ${i * 0.05}s forwards`
                    }}
                  >
                    {char === ' ' ? '\u00A0' : char}
                  </span>
                ))}
              </div>
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-red-500/20 to-transparent animate-pulse"></div>
            </div>
          </div>
          
          <div className="text-center">
            <p className="text-xl font-medium animate-pulse mb-4">
              Please wait while we erase this from existence...
            </p>
            <div className="flex justify-center items-center gap-2">
              <div className="w-3 h-3 bg-pink-500 rounded-full animate-bounce"></div>
              <div className="w-3 h-3 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-3 h-3 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
          </div>
        </div>
      ) : null}
      
      {showCertificate && <Certificate onClose={handleCloseModal} />}
      
      <style jsx>{`
        @keyframes fadeOut {
          0% { opacity: 1; }
          100% { opacity: 0; transform: translateY(-10px); }
        }
      `}</style>
    </div>
  );
};

export default MemoryInput;